#define __INTRINSIC_ONLYSPECIAL
#define __INTRINSIC_SPECIAL___readfsdword // Causes code generation in intrin-impl.h

#include <intrin.h>
